# REPORT CÁ NHÂN

Mentor : Nguyễn Đăng Khoa

Full_Name : Võ Khả Nam

Roll_Number : QE200059

Tổng quan quá trình sử dụng AI

AI cung cấp kiến thức về các thuật ngữ và công cụ phục vụ cho dự án trong ngữ cảnh đã biết.Code và hỗ trợ giải thích cho người dùng nắm được nội dung giúp tiết kiệm thời gian hơn.Cung cấp gợi ý vẽ UseCase , Class Diagram , .....Hỗ trợ test-case , test nhanh bằng Junit.Gợi ý các phương pháp nhằm giúp người dùng có sự lựa chọn cho hướng đi của dự án chứ không phải chỉ bó buộc theo 1 hướng nhất định.
-Đánh giá nhanh : Khá tốt cho việc đọc và đưa ra kế hoạch ,chưa hoàn thiện cho việc code khi còn gặp 1 lỗi nhiều lần

Chất lượng Output

Có sự khác biệt về góc nhìn của những AI khác nhau.Chất lượng output về kiến thức và về dự án có sự khác biệt , Gemini cung cấp kiến thức , review và report lại sau mỗi lần fix bug hoặc fix logic dự án khá tốt trong khi Claude đảm nhận việc viết code và test-case ổn hơn .Chất lượng Output có sự khác biệt rõ khi so giữa từng AI với từng mảng khác nhau.Có sự chênh lệch về độ phức tạp cũng như tính chính xác khi dùng trong việc code và Claude làm việc này tốt hơn.

Đánh giá nhanh :Nhìn chung output khá ổn nhưng cần review và góp ý của người dùng.

Lỗi AI mắc phải

Tuy khá tốt về Output nhưng nhìn chung vẫn còn những lỗi như giải thích lan man . Đôi khi quên ngữ cảnh , cần có sự review và phải biện lại của người dùng.Đôi khi đang nói về vấn đề này lại nhầm sang vấn đề khác.

Đánh giá nhanh : Người dùng cần review lại để tránh việc bị AI dắt

Bài học rút ra

Cung cấp rõ 1 ngữ cảnh hoặc tài liệu nêu những yêu cầu 1 cách rõ ràng ,trực quan đồng thời luôn cần sự review và rà soát liên tục của người dùng.
